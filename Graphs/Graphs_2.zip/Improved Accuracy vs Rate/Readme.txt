Config:

Regen rate is shown in the graph by labels
Regen freq is 5 iterations/regen
Dataset is smart_home_split

Every model is run 10000 iterations, and the 200 samples are 
collected by picking the maximum of the 50-iteration intervals.
Picking medium will generate similar results.
